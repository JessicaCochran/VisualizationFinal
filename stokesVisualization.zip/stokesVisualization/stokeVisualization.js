var csvData;
let svg = d3.select("svg")
            .style("background-color", "lightgrey");

let mapGroup = svg.append("g").attr("class", "map-group");
let plotGroup = svg.append("g").attr("class", "plot-group");

let projection;

const xScale = d3.scaleLinear()
                .domain([25,45])
                .range([1000, 2000]);
const yScale = d3.scaleLinear()
                .domain([25,60])
                .range([750,0]);

function getWeekNumber(date) {
    const currentDate = new Date(date);
    const startOfYear = new Date(currentDate.getFullYear(), 0, 1);
    const pastDays = Math.floor((currentDate - startOfYear) / (24 * 60 * 60 * 1000));
    return Math.ceil((pastDays + startOfYear.getDay() + 1) / 7);
}

function vizDriver(selectedYears){
    let yearFileNameColor={};
    yearFileNameColor['2017']=['White_Stork_Adults_2017_part.csv','blue'];
    yearFileNameColor['2018']=['White Stork Adults 2018_part.csv','red'];
    yearFileNameColor['2019']=['White Stork Adults 2019_part.csv','green'];
    yearFileNameColor['2020']=['White Stork Adults 2020_part.csv','purple'];

    plotGroup.selectAll("*").remove();

    plotGroup.append("text")
        .attr("x", 1500)
        .attr("y", 50)
        .attr("text-anchor", "middle")
        .style("font-size", "20px")
        .style("font-weight", "bold")
        .text("External Temperature");

    plotGroup.append("g")
        .attr("transform", `translate(100,850)`)
        .call(d3.axisBottom(xScale).ticks().tickFormat(d => `Week ${d}`));
    
    plotGroup.append("text")
        .attr("x", 1500)
        .attr("y", 900)
        .attr("text-anchor", "middle")
        .style("font-size", "16px")
        .text("Week");

    plotGroup.append("g")
        .attr("transform", `translate(1100,100)`)
        .call(d3.axisLeft(yScale));
    
    plotGroup.append("text")
        .attr("transform", "rotate(-90)")
        .attr("x", -400)
        .attr("y", 1050)
        .attr("text-anchor", "middle")
        .style("font-size", "16px")
        .text("Temperature");
    
    if(selectedYears.length != 0){
        for(let i=0;i<selectedYears.length;i++){
            plotMigrationData(yearFileNameColor[selectedYears[i]]);
            plotTemperature(yearFileNameColor[selectedYears[i]])
        }
    }

}

function plotTemperature(yearFileNameColor){
    let fileName = yearFileNameColor[0];
    let color = yearFileNameColor[1];
    d3.csv(fileName).then(function(data) {
        temperatureData=data
        .filter(d => d['external-temperature'] !== "" && d['external-temperature'] !== null && d['external-temperature'] !== undefined)
        .map(d => ({temperature: Number(d['external-temperature']),timestamp: d['timestamp']}));
        let sortDataTemp = temperatureData.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
        console.log(temperatureData);
        console.log(sortDataTemp);
        let groupedByWeek = sortDataTemp.reduce((acc, entry) => {
            const weekNumber = getWeekNumber(entry.timestamp);
            if (!acc[weekNumber]) {
                acc[weekNumber] = { week: weekNumber, temperatures: [] };
            }
            acc[weekNumber].temperatures.push(entry.temperature);
            return acc;
        }, {});
        let weeklyAverages = Object.values(groupedByWeek).map(group => ({
            week: group.week,
            averageTemperature: group.temperatures.reduce((sum, temp) => sum + temp, 0) / group.temperatures.length
        }));
        console.log(weeklyAverages);

        const line = d3.line()
            .x(d => xScale(d.week))
            .y(d => yScale(d.averageTemperature));
        
        plotGroup.append("path")
            .datum(weeklyAverages)
            .attr("fill", "none")
            .attr("stroke", color)
            .attr("stroke-width", 2)
            .attr("transform", `translate(100,100)`)
            .attr("d", line);
    
        const symbol = d3.symbol()
            .size(100)
            .type(d3.symbolTriangle);
    
        plotGroup.selectAll(`.data-point-${color}`)
            .data(weeklyAverages)
            .enter()
            .append("path")
            .attr("class", `data-point data-point-${color}`)
            .attr("d", symbol)
            .attr("fill", color)
            .attr("transform", d => `translate(${xScale(d.week)+100},${yScale(d.averageTemperature)+100})`);
    });
}

function plotMigrationData(yearFileNameColor){
    let fileName = yearFileNameColor[0];
    let color = yearFileNameColor[1];
    d3.csv(fileName).then(function(data) {
        let csvData = Array.from(
            new Set(data.map(d => `${Number(d['location-long'])},${Number(d['location-lat'])}`))
        ).map(uniqueString => {
            let [longitude, latitude] = uniqueString.split(',');
            return [Number(longitude), Number(latitude)];
        });
        csvData.forEach((d) => {
            plotGroup.append("circle")
                .attr("cx", projection(d)[0])
                .attr("cy", projection(d)[1])
                .attr("r", 0)
                .attr("fill", color)
                .attr("r", 5);
        });
        });
        
}

d3.json("custom.geo.json").then(function(geo_json) {
    projection = d3.geoEquirectangular()
        .fitSize([1000, 1000], geo_json);

    let generator = d3.geoPath()
        .projection(projection);

    mapGroup.append("text")
        .attr("x", 500)
        .attr("y", 50)
        .attr("text-anchor", "middle")
        .style("font-size", "20px")
        .style("font-weight", "bold")
        .text("Migration Pattern");
    
    mapGroup.selectAll('paths')
        .data(geo_json.features)
        .enter()
        .append('path')
        .attr('d', generator)
        .attr('stroke', '#333')
        .attr('fill', '#cce5df')
        .attr('stroke-width', 0.5);
});



